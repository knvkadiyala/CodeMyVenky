import { LightningElement, api } from 'lwc';
import { subscribe, unsubscribe } from 'lightning/messageService';
import ANALYTICS_CHANNEL from '@salesforce/messageChannel/AnalyticsMessageChannel__c';

export default class ContactAnalyticsTable extends LightningElement {
    @api contacts = [];
    subscription = null;
    
    columns = [
        { label: 'Name', fieldName: 'Name', type: 'text' },
        { label: 'Email', fieldName: 'Email', type: 'email' },
        { label: 'Phone', fieldName: 'Phone', type: 'phone' },
        { label: 'Title', fieldName: 'Title', type: 'text' },
        { label: 'Created Date', fieldName: 'CreatedDate', type: 'date' }
    ];

    connectedCallback() {
        this.subscribeToMessageChannel();
    }

    disconnectedCallback() {
        this.unsubscribeFromMessageChannel();
    }

    subscribeToMessageChannel() {
        this.subscription = subscribe(
            ANALYTICS_CHANNEL,
            (message) => this.handleMessage(message)
        );
    }

    handleMessage(message) {
        if (message.filterData) {
            // Update table based on dashboard filters
            this.applyFilters(message.filterData);
        }
    }

    handleRowSelection(event) {
        const selectedRows = event.detail.selectedRows;
        // Publish selection to dashboard
        this.dispatchEvent(new CustomEvent('rowselection', {
            detail: { selectedRows }
        }));
    }
}