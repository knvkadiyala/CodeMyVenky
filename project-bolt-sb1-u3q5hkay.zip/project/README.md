# CRM Analytics Dashboard with LWC Integration

This project contains a Salesforce CRM Analytics dashboard with an integrated Lightning Web Component (LWC) data table. The dashboard provides interactive filtering and bi-directional communication between the dashboard and the LWC component.

## Project Structure

```
force-app/
├── main/
    └── default/
        ├── lwc/
        │   └── contactAnalyticsTable/
        │       ├── contactAnalyticsTable.html
        │       ├── contactAnalyticsTable.js
        │       └── contactAnalyticsTable.js-meta.xml
        ├── messageChannels/
        │   └── AnalyticsMessageChannel.messageChannel-meta.xml
        └── wave/
            ├── Contact_Analytics.wdf
            ├── Contact_Analytics.wdf-meta.xml
            └── Contact_Analytics_Dashboard.json
```

## Prerequisites

- Salesforce Developer Org with CRM Analytics enabled
- Visual Studio Code with Salesforce Extension Pack
- Salesforce CLI
- CRM Analytics license

## Installation

1. Clone this repository
2. Authenticate with your Salesforce org:
   ```bash
   sf org login web
   ```
3. Deploy the components:
   ```bash
   sf project deploy start
   ```

## Configuration

1. In Salesforce Setup:
   - Ensure CRM Analytics is enabled
   - Assign necessary permissions to users

2. In Analytics Studio:
   - Create a new app named "Contact Analytics"
   - Import the dashboard JSON
   - Configure dataset security

## Features

- Interactive Contact Analytics Dashboard
- Real-time data updates
- Bi-directional filtering
- Responsive layout
- Security compliance

## Security

- Configure sharing rules
- Set up row-level security
- Enable field-level security
- Set appropriate user permissions

## Development

To make changes to the components:

1. Create a new branch
2. Make your changes
3. Test in a sandbox environment
4. Deploy to production using change sets or CLI

## License

This project is licensed under the MIT License - see the LICENSE file for details.